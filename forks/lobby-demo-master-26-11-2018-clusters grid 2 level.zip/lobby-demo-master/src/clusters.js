function ClasterChart() {

    //Main entry point
    var clusterChart=function clusterChart(selector,data) {
        nodes = createNodes(data);

    }
    //Return the chart function from closure
    return clusterChart
}